# frozen_string_literal: true

class Api::DocsController < ApplicationController
  layout 'docs'

  def index
    render  
  end
end